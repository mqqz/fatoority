using System.Text.Json;
using System.Globalization;
using Fatoora;

public static class Program
{
    private const ZatcaEnvironment Sandbox = ZatcaEnvironment.NonProduction; // Integration Sandbox only.
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static string Required(string name) =>
        !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(name))
            ? Environment.GetEnvironmentVariable(name)!.Trim()
            : throw new InvalidOperationException($"Set {name} first");
    private static void Save(string path, object value) =>
        File.WriteAllText(path, JsonSerializer.Serialize(value, JsonOptions) + "\n");
    private static object[] Messages(nuint count, Func<nuint, ValidationMessage> get)
    {
        var result = new List<object>();
        for (nuint i = 0; i < count; i++)
        {
            using var message = get(i);
            result.Add(new { code = message.Code, message = message.Message });
        }
        return result.ToArray();
    }
    public static void HandleResponse(ValidationResponse response, string output)
    {
        using var results = response.ValidationResults();
        var summary = new {
            http_status = response.HttpStatus, outcome = response.Outcome.ToString(),
            reporting_status = response.ReportingStatusRaw,
            validation_status = results.StatusRaw,
            info = Messages(results.InfoLen, results.InfoMessage),
            warnings = Messages(results.WarningLen, results.WarningMessage),
            errors = Messages(results.ErrorLen, results.ErrorMessage),
        };
        Save(Path.Combine(output, "response.json"), summary);
        Console.WriteLine(JsonSerializer.Serialize(summary, JsonOptions));
        response.EnsureAccepted(); // A successful HTTP status alone is insufficient.
        Console.WriteLine("Sandbox reporting accepted. Keep any warnings in response.json.");
    }
    public static void Run(string inputPath, bool submit)
    {
        string certificate = File.ReadAllText(Required("ZATCA_CERT_PATH"));
        string key = File.ReadAllText(Required("ZATCA_KEY_PATH"));
        string token = submit ? Required("ZATCA_TOKEN") : "";
        string secret = submit ? Required("ZATCA_SECRET") : "";
        using var input = JsonDocument.Parse(File.ReadAllText(inputPath));
        var data = input.RootElement;
        var seller = data.GetProperty("seller");
        string Field(JsonElement parent, string name) => parent.GetProperty(name).GetString()
            ?? throw new InvalidOperationException($"Missing input field: {name}");
        string uuid = Guid.NewGuid().ToString();
        string output = Path.Combine("runs", uuid);
        if (Directory.Exists(output)) throw new IOException("Output directory already exists");
        Directory.CreateDirectory(output);
        Console.WriteLine($"Artifacts: {output}");
        var state = new Dictionary<string, object> {
            ["uuid"] = uuid, ["invoice_id"] = Field(data, "invoice_id"),
            ["stage"] = "create", ["submitted"] = false,
        };
        Save(Path.Combine(output, "state.json"), state);
        try
        {
            using var builder = InvoiceBuilder.New(InvoiceTypeKind.Tax, InvoiceSubType.Simplified, null, null, null, null);
            builder.SetId(Field(data, "invoice_id"));
            builder.SetUuid(uuid);
            builder.SetIssueDatetime(DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture));
            builder.SetCurrency("SAR");
            builder.SetInvoiceCounter(ulong.Parse(Field(data, "invoice_counter")));
            builder.SetPreviousInvoiceHash(Field(data, "previous_invoice_hash"));
            using (var means = PaymentMeans.New("10", null))
                builder.AddPaymentMeans(means);
            builder.SetVatCategory(VatCategory.Standard);
            using var address = Address.New("SA", Field(seller, "city"), Field(seller, "street"),
                Field(seller, "building_number"), Field(seller, "postal_code"), null,
                Field(seller, "additional_number"), Field(seller, "district"));
            builder.SetSeller(Field(seller, "name"), address, Field(seller, "vat_id"), Field(seller, "crn"), "CRN");
            builder.AddLineItem("دفتر", 2m, "PCE", 50m, 15m, VatCategory.Standard);
            using var invoice = builder.Build();
            File.WriteAllText(Path.Combine(output, "invoice.xml"), invoice.Xml);
            Console.WriteLine("Created: SAR 100 net + SAR 15 VAT = SAR 115 payable");
            state["stage"] = "sign";
            using var signer = InvoiceSigner.FromPem(certificate, key);
            using var signed = signer.Sign(invoice);
            string signedXml = signed.Xml;
            File.WriteAllText(Path.Combine(output, "signed.xml"), signedXml);
            state["invoice_hash"] = signed.InvoiceHash;
            state["stage"] = "validate";
            using var report = Xml.ValidateZatca(signedXml, JsonSerializer.Serialize(new {
                previous_invoice_hash = Field(data, "previous_invoice_hash"),
            }));
            File.WriteAllText(Path.Combine(output, "validation.json"), report.ToJson());
            if (!report.IsValid)
                throw new InvalidOperationException("Local validation failed; inspect validation.json. Nothing was submitted.");
            Console.WriteLine("Local validation passed; inspect validation.json for warnings");
            if (!submit)
            {
                state["stage"] = "local_only";
                Console.WriteLine("Local run complete. No reporting request sent. Use --submit with sandbox credentials.");
                return;
            }
            state["stage"] = "report";
            state["submitted"] = true; // Attempted; a failed connection can leave the outcome unknown.
            Save(Path.Combine(output, "state.json"), state);
            using var credentials = ProductionCsid.Create(Sandbox, null, token, secret);
            using var config = Config.New(Sandbox);
            using var client = ZatcaClient.Create(config);
            using var response = client.ReportSimplifiedInvoice(signed, credentials, ClearanceMode.Disabled, "en");
            HandleResponse(response, output);
            state["stage"] = "accepted";
        }
        catch (Exception error)
        {
            state["error_type"] = error.GetType().Name;
            if (error is FfiException native) // InvalidInputException, NetworkException, ...
            {
                using var details = JsonDocument.Parse(native.DetailsJson);
                Save(Path.Combine(output, "error.json"), new { code = native.Code, kind = native.Kind?.ToString(), details = details.RootElement });
            }
            throw;
        }
        finally { Save(Path.Combine(output, "state.json"), state); }
    }
    public static int Main(string[] args)
    {
        try
        {
            string input = "input.json";
            bool submit = false;
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--submit") submit = true;
                else if (args[i] == "--input" && i + 1 < args.Length) input = args[++i];
                else throw new ArgumentException("Usage: dotnet run -- [--input input.json] [--submit]");
            }
            Run(input, submit);
            return 0;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine($"Stopped: {error.Message}");
            Console.Error.WriteLine("No automatic retry. Inspect saved artifacts before another run.");
            return 1;
        }
    }
}
